#pragma once
#include_next <string.h>
#define strdup _strdup