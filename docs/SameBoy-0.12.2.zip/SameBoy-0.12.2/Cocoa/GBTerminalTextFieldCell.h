#import <Cocoa/Cocoa.h>

@interface GBTerminalTextFieldCell : NSTextFieldCell

@end
