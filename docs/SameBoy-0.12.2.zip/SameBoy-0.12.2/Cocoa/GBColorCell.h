#import <Cocoa/Cocoa.h>

@interface GBColorCell : NSTextFieldCell

@end
