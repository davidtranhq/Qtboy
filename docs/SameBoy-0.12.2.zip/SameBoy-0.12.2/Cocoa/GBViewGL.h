#import "GBView.h"

@interface GBViewGL : GBView

@end
